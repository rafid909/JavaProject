# Pharmacy Management
Depertmental store management system

## Language
Java, javascript, HTML, CSS
